--
-- PostgreSQL database dump
--

\restrict t6cawI6aAcO8RrwgTXxpqRh17evHI5ngkpgZ72e002Jtq4itQntXRldK3b5KKDb

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: frutales
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO frutales;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: frutales
--

CREATE TABLE public.projects (
    id text NOT NULL,
    name text NOT NULL,
    "productName" text NOT NULL,
    "processType" text NOT NULL,
    "initialQty" numeric(12,3) NOT NULL,
    "purchasePrice" numeric(12,2) NOT NULL,
    "reductionPct" numeric(5,2) NOT NULL,
    "netYield" numeric(12,3) NOT NULL,
    "netYieldOverridden" boolean DEFAULT false NOT NULL,
    "sellingPrice" numeric(12,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.projects OWNER TO frutales;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: frutales
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
3629cc5d-9dbb-48eb-bc4c-de5c3d73603d	a30289bb948705346ef5c4ffa182552f90ce7042637298ebe48ef4be37d11b14	2026-10-16 01:26:48.46551+00	20261016010032_init	\N	\N	2026-10-16 01:26:48.45017+00	1
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: frutales
--

COPY public.projects (id, name, "productName", "processType", "initialQty", "purchasePrice", "reductionPct", "netYield", "netYieldOverridden", "sellingPrice", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: frutales
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: frutales
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects_createdAt_idx; Type: INDEX; Schema: public; Owner: frutales
--

CREATE INDEX "projects_createdAt_idx" ON public.projects USING btree ("createdAt");


--
-- PostgreSQL database dump complete
--

\unrestrict t6cawI6aAcO8RrwgTXxpqRh17evHI5ngkpgZ72e002Jtq4itQntXRldK3b5KKDb

